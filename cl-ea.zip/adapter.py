# see https://api.dclimate.net/ for reference
# implementing metadata and gridded data retrieval for

import ipfshttpclient, json, datetime, os, tarfile, gzip, pickle, zipfile
from io import BytesIO
from adapter_utils import get_gridcell_history

GATEWAY_IPFS_ID = '/ip4/134.122.126.13/tcp/4001/p2p/12D3KooWM8nN6VbUka1NeuKnu9xcKC56D17ApAVRDyfYNytzUsqG'

class Adapter:

    task_map = {'dataset_information': 0, 'grid_file_dataset_history': 1}#, 'ghcn_dataset_history': 2}
    task_params = [
                    ['full_metadata', 'dataset'],
                    ['lat', 'lon', 'dataset', 'also_return_metadata', 'use_imperial_units', 'also_return_snapped_coordinates', 'convert_to_local_time', 'as_of'],
                    # ['station_id', 'weather_variable', 'dataset', 'use_imperial_units'],
    ]

    def __init__(self, input, ipfs_timeout=None):

        self.id = input.get('id', '1')
        self.request_data = input.get('data')
        self.ipfs_timeout = ipfs_timeout

        if self.validate_request_data():
            self.ipfs = ipfshttpclient.connect(timeout=ipfs_timeout)
            self.set_params()
            self.create_request()
        else:
            self.result_error('No data provided')

    def validate_request_data(self):
        if self.request_data is None:
            return False
        if self.request_data == {}:
            return False
        return True

    def set_params(self):
        task_name = self.request_data.get('task')
        self.params = {'task': task_map.get(task_name)}
        for param in task_params[self.params.get('task')]:
            self.params[param] = self.request_data.get(param)

    def get_metadata(self):
        # stub
        return

    def get_gridded_data(self):
        f = get_gridcell_hash(
                                    lat=self.params.get('lat'),
                                    lon=self.params.get('lon'),
                                    dataset=self.params.get('dataset'),
                                    also_return_snapped_coordinates=self.params.get('also_return_snapped_coordinates'),
                                    also_return_metadata=self.params.get('also_return_metadata'),
                                    use_imperial_units=self.params.get('use_imperial_units'),
                                    convert_to_local_time=self.params.get('convert_to_local_time'),
                                    as_of=self.params.get('as_of'),
                                    ipfs_timeout=self.params.get('ipfs_timeout'),
        )
        return f

    def get_ipfs_path(self):
        task_parsers = [self.get_metadata, self.get_gridded_data,]
        f = task_parsers[self.params.get('task')]
        return f

    def create_request(self):
        try:
            f = self.get_ipfs_path()
            self.ipfs._client.request('/swarm/connect', (GATEWAY_IPFS_ID,))
            ipfs_obj = BytesIO(self.ipfs.cat(f))

            # self.result = BytesIO(ipfs_obj)

            #
            # try:
            #     with tarfile.open(fileobj=BytesIO(ipfs_obj)) as tar:
            #         member = tar.getmember(self.gzip_name)
            #         with gzip.open(tar.extractfile(member)) as gz:
            #             cell_text = gz.read().decode('utf-8')

        #     request(self.base_url, params)
        #     data = response.json()
        #     self.result = data[self.to_param]
        #     data['result'] = self.result
            self.result_success(data)
        except Exception as e:
            self.result_error(e)

    def result_success(self, data):
        self.result = {
            'jobRunID': self.id,
            'data': data,
            'result': self.result,
            'statusCode': 200,
        }

    def result_error(self, error):
        self.result = {
            'jobRunID': self.id,
            'status': 'errored',
            'error': f'There was an error: {error}',
            'statusCode': 500,
        }
